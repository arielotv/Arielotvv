package com.arielotv.app

import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView

/** ArieloTV starter. Add only verified, authorized stream URLs to CHANNELS. */
data class TvChannel(val name: String, val category: String, val streamUrl: String = "", val officialUrl: String = "")

class MainActivity : AppCompatActivity() {
    private val channels = listOf(
        TvChannel("TV Pública", "Aire", officialUrl = "https://www.tvpublica.com.ar/vivo/"),
        TvChannel("América TV", "Aire", officialUrl = "https://www.americatv.com.ar/vivo"),
        TvChannel("El Trece", "Aire", officialUrl = "https://www.eltrecetv.com.ar/"),
        TvChannel("Telefe", "Aire", officialUrl = "https://telefe.com/"),
        TvChannel("El Nueve", "Aire", officialUrl = "https://www.elnueve.com/"),
        TvChannel("C5N", "Noticias", officialUrl = "https://www.c5n.com/"),
        TvChannel("Canal 26", "Noticias", officialUrl = "https://www.canal26.com/"),
        TvChannel("Crónica TV", "Noticias", officialUrl = "https://www.cronica.com.ar/"),
        TvChannel("DeporTV", "Deportes", officialUrl = "https://www.deportv.gob.ar/"),
        TvChannel("TECtv", "Ciencia y tecnología", officialUrl = "https://tectv.gob.ar/"),
        TvChannel("Canal Encuentro", "Cultura", officialUrl = "https://encuentro.gob.ar/"),
        TvChannel("Pakapaka", "Infantiles", officialUrl = "https://pakapaka.gob.ar/")
    )
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var trackSelector: DefaultTrackSelector
    private lateinit var qualitySpinner: Spinner
    private lateinit var status: TextView
    private var currentChannel: TvChannel? = null
    private val qualities = listOf("Automática (ahorra datos)", "Baja · hasta 240p", "Media · hasta 360p", "Alta · hasta 480p", "HD · hasta 720p")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        trackSelector = DefaultTrackSelector(this).apply {
            setParameters(buildUponParameters().setMaxVideoSize(426, 240).setForceLowestBitrate(true))
        }
        player = ExoPlayer.Builder(this).setTrackSelector(trackSelector).build()
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 12)
            setBackgroundColor(android.graphics.Color.rgb(6, 16, 31))
        }
        val logo = TextView(this).apply {
            text = "ArieloTV"
            textSize = 30f
            setTextColor(android.graphics.Color.rgb(30, 160, 255))
            setPadding(0, 4, 0, 14)
        }
        root.addView(logo)
        playerView = PlayerView(this).apply {
            player = this@MainActivity.player
            useController = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 220)
        }
        root.addView(playerView)
        status = TextView(this).apply {
            text = "Elegí un canal autorizado para comenzar. Calidad inicial: baja (240p)."
            textSize = 14f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, 12, 0, 10)
        }
        root.addView(status)
        label(root, "Calidad de video por canal")
        qualitySpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, qualities)
            setSelection(1)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) = applyQuality(position)
            }
        }
        root.addView(qualitySpinner)
        label(root, "Canales gratuitos · tocá para abrir la señal oficial")
        val list = ListView(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, channels.map { "${it.name}  ·  ${it.category}" })
            setBackgroundColor(android.graphics.Color.rgb(12, 29, 51))
            setOnItemClickListener { _, _, position, _ -> playChannel(channels[position]) }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(list)
        setContentView(root)
    }

    private fun label(root: LinearLayout, value: String) {
        root.addView(TextView(this).apply {
            text = value; textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, 10, 0, 6)
        })
    }

    private fun applyQuality(position: Int) {
        val builder = trackSelector.buildUponParameters()
        when (position) {
            0 -> builder.clearVideoSizeConstraints().setForceLowestBitrate(false)
            1 -> builder.setMaxVideoSize(426, 240).setForceLowestBitrate(true)
            2 -> builder.setMaxVideoSize(640, 360).setForceLowestBitrate(false)
            3 -> builder.setMaxVideoSize(854, 480).setForceLowestBitrate(false)
            else -> builder.setMaxVideoSize(1280, 720).setForceLowestBitrate(false)
        }
        trackSelector.setParameters(builder)
        currentChannel?.let { status.text = "${it.name} · ${qualities[position]}" }
    }

    private fun playChannel(channel: TvChannel) {
        currentChannel = channel
        if (channel.streamUrl.isBlank()) {
            status.text = "Abriendo la página oficial de ${channel.name}. La reproducción y calidad dependen del sitio de origen."
            if (channel.officialUrl.isNotBlank()) {
                startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(channel.officialUrl)))
            }
            return
        }
        val item = MediaItem.Builder().setUri(Uri.parse(channel.streamUrl)).setMimeType(MimeTypes.APPLICATION_M3U8).build()
        player.setMediaItem(item)
        player.prepare()
        player.playWhenReady = true
        status.text = "Reproduciendo ${channel.name} · ${qualities[qualitySpinner.selectedItemPosition]}"
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
