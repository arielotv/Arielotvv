# ArieloTV — proyecto Android inicial

Prototipo Android con un catálogo inicial de 12 canales/señales para abrir sus sitios oficiales, más un reproductor Media3/ExoPlayer preparado para enlaces HLS autorizados.

## Incluye
- Catálogo: TV Pública, América TV, El Trece, Telefe, El Nueve, C5N, Canal 26, Crónica TV, DeporTV, TECtv, Canal Encuentro y Pakapaka.
- Selector de calidad para transmisiones HLS compatibles (240p, 360p, 480p y 720p; automática).
- Prioridad inicial de reproducción en 240p cuando la transmisión directa configurada ofrezca variantes de calidad.

## Importante
El catálogo abre las páginas oficiales en el navegador; no todas ofrecen un enlace directo que pueda reproducirse dentro de la app. No se han inventado URLs de streaming directas. Para reproducir dentro de ArieloTV hay que añadir URLs HLS autorizadas (`.m3u8`) en `MainActivity.kt`. El selector solo puede elegir resoluciones disponibles en la señal; no convierte una señal HD a 240p por sí solo.

## Cómo compilar el APK
1. Abrí esta carpeta desde Android Studio.
2. Usá JDK 17 y Android SDK 35; esperá la sincronización de Gradle.
3. Elegí **Build > Build APK(s)**.
4. El APK debug suele generarse en `app/build/outputs/apk/debug/app-debug.apk`.

Este ZIP es código fuente, no un APK ya compilado. No se pudo verificar una compilación en este entorno.
